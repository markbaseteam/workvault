


## Global 66 
![Global66](Pasted%20image%2020230206154952.png)
