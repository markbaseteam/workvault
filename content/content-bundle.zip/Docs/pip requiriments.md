pip install -r requirements.txt
Collecting Django==4.0.8
  Downloading Django-4.0.8-py3-none-any.whl (8.0 MB)
     |████████████████████████████████| 8.0 MB 3.3 MB/s
Collecting djangorestframework==3.13.1
  Downloading djangorestframework-3.13.1-py3-none-any.whl (958 kB)
     |████████████████████████████████| 958 kB 3.2 MB/s
Collecting mssql-django==1.1.2
  Downloading mssql_django-1.1.2-py3-none-any.whl (72 kB)
     |████████████████████████████████| 72 kB 5.1 MB/s
Collecting wfastcgi==3.0.0
  Downloading wfastcgi-3.0.0.tar.gz (14 kB)
Collecting requests==2.27.1
  Downloading requests-2.27.1-py2.py3-none-any.whl (63 kB)
     |████████████████████████████████| 63 kB 790 kB/s
Collecting django-filter==21.1
  Downloading django_filter-21.1-py3-none-any.whl (81 kB)
     |████████████████████████████████| 81 kB ...
Collecting python-dateutil==2.8.2
  Downloading python_dateutil-2.8.2-py2.py3-none-any.whl (247 kB)
     |████████████████████████████████| 247 kB 6.4 MB/s
Collecting django-simple-history==2.12.0
  Downloading django_simple_history-2.12.0-py2.py3-none-any.whl (46 kB)
     |████████████████████████████████| 46 kB ...
Collecting gunicorn==20.1.0
  Downloading gunicorn-20.1.0-py3-none-any.whl (79 kB)
     |████████████████████████████████| 79 kB 5.1 MB/s
Collecting whitenoise==6.0.0
  Downloading whitenoise-6.0.0-py3-none-any.whl (19 kB)
Collecting unicodedata2==15.0.0
  Downloading unicodedata2-15.0.0-cp311-cp311-win_amd64.whl (427 kB)
     |████████████████████████████████| 427 kB 6.4 MB/s
Collecting django-webpack-loader==1.8.0
  Downloading django_webpack_loader-1.8.0-py2.py3-none-any.whl (17 kB)
Collecting asgiref<4,>=3.4.1
  Downloading asgiref-3.6.0-py3-none-any.whl (23 kB)
Collecting tzdata
  Downloading tzdata-2022.7-py2.py3-none-any.whl (340 kB)
     |████████████████████████████████| 340 kB 3.3 MB/s
Collecting sqlparse>=0.2.2
  Downloading sqlparse-0.4.3-py3-none-any.whl (42 kB)
     |████████████████████████████████| 42 kB 3.2 MB/s
Collecting six
  Downloading six-1.16.0-py2.py3-none-any.whl (11 kB)
Collecting pytz
  Downloading pytz-2022.7.1-py2.py3-none-any.whl (499 kB)
     |████████████████████████████████| 499 kB 6.4 MB/s
Requirement already satisfied: setuptools>=3.0 in c:\prg\work\virtualenv\lib\site-packages (from gunicorn==20.1.0->-r requirements.txt (line 9)) (65.5.0)
Collecting pyodbc>=3.0
  Downloading pyodbc-4.0.35-cp311-cp311-win_amd64.whl (66 kB)
     |████████████████████████████████| 66 kB 4.5 MB/s
Collecting idna<4,>=2.5
  Downloading idna-3.4-py3-none-any.whl (61 kB)
     |████████████████████████████████| 61 kB 4.8 MB/s
Collecting charset-normalizer~=2.0.0
  Downloading charset_normalizer-2.0.12-py3-none-any.whl (39 kB)
Collecting certifi>=2017.4.17
  Downloading certifi-2022.12.7-py3-none-any.whl (155 kB)
     |████████████████████████████████| 155 kB 3.2 MB/s
Collecting urllib3<1.27,>=1.21.1
  Downloading urllib3-1.26.14-py2.py3-none-any.whl (140 kB)
     |████████████████████████████████| 140 kB 6.8 MB/s
Using legacy 'setup.py install' for wfastcgi, since package 'wheel' is not installed.
Installing collected packages: tzdata, sqlparse, asgiref, urllib3, six, pytz, pyodbc, idna, Django, charset-normalizer, certifi, whitenoise, wfastcgi, unicodedata2, requests, python-dateutil, mssql-django, gunicorn, djangorestframework, django-webpack-loader, django-simple-history, django-filter
    Running setup.py install for wfastcgi ... done
Successfully installed Django-4.0.8 asgiref-3.6.0 certifi-2022.12.7 charset-normalizer-2.0.12 django-filter-21.1 django-simple-history-2.12.0 django-webpack-loader-1.8.0 djangorestframework-3.13.1 gunicorn-20.1.0 idna-3.4 mssql-django-1.1.2 pyodbc-4.0.35 python-dateutil-2.8.2 pytz-2022.7.1 requests-2.27.1 six-1.16.0 sqlparse-0.4.3 tzdata-2022.7 unicodedata2-15.0.0 urllib3-1.26.14 wfastcgi-3.0.0 whitenoise-6.0.0