---
quickshare-date: 2023-02-17 16:53:00
quickshare-url: "https://noteshare.space/note/cle8y7e53574401pjqtoohpic#nBQ+dJ9J+wOySPH0UhFLCXh9blQep9PyS2SHArXFSQQ"
---



# Apps & Links
---

## email
https://outlook.office.com/mail/

## OneLogin Portal
Martha Fowler

You should be able to login to ONE login to authenticate
[https://rescue.onelogin.com/login2/?return=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1cmkiOiJodHRwczovL3Jlc2N1ZS5vbmVsb2dpbi5jb20vIiwiYXVkIjoiQUNDRVNTIiwiZmZfbXVsdGlwbGVfYnJhbmRzIjpmYWxzZSwiaXNzIjoiTU9OT1JBSUwiLCJicmFuZF9pZCI6Im1hc3RlciIsImV4cCI6MTY3NTM2MTIyOSwicGFyYW1zIjp7fSwibWV0aG9kIjoiZ2V0In0.js83B2ba5a-fB9CIdAn_xlVeBb6aMP6OZ_uHsSsrxeg#app=](https://rescue.onelogin.com/login2/?return=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1cmkiOiJodHRwczovL3Jlc2N1ZS5vbmVsb2dpbi5jb20vIiwiYXVkIjoiQUNDRVNTIiwiZmZfbXVsdGlwbGVfYnJhbmRzIjpmYWxzZSwiaXNzIjoiTU9OT1JBSUwiLCJicmFuZF9pZCI6Im1hc3RlciIsImV4cCI6MTY3NTM2MTIyOSwicGFyYW1zIjp7fSwibWV0aG9kIjoiZ2V0In0.js83B2ba5a-fB9CIdAn_xlVeBb6aMP6OZ_uHsSsrxeg#app= "https://rescue.onelogin.com/login2/?return=eyj0exaioijkv1qilcjhbgcioijiuzi1nij9.eyj1cmkioijodhrwczovl3jlc2n1zs5vbmvsb2dpbi5jb20viiwiyxvkijoiqundrvntiiwizmzfbxvsdglwbgvfynjhbmrzijpmywxzzswiaxnzijoitu9ot1jbsuwilcjicmfuzf9pzci6im1hc3rlciisimv4cci6mty3ntm2mtiyoswicgfyyw1zijp7fswibwv0ag9kijoiz2v0in0.js83b2ba5a-fb9cidan_xlvebb6amp6oz_uhsssrxeg#app=")

## Jira
[Board](https://theirc.atlassian.net/jira/software/c/projects/ED/boards/153)
[Backlog](https://theirc.atlassian.net/jira/software/c/projects/ED/boards/153/backlog?issueLimit=100)


## Confluence
	https://confluence.rescue.org/display/APDV/Deploying+Django+Apps+To+Production+Servers
- [IRC Built System Integrations Diagram](https://confluence.rescue.org/pages/diffpages.action?pageId=5373956&originalId=45717715)
- [People Directory](https://confluence.rescue.org/display/APDV/People+Directory)
- 

