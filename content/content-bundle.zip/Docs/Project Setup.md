[2:35 PM] Federico Aguer
#people/FedeAguer 
te pase al mail el [[localsettings]]
en la carpeta principal -**"C:\\prg\\work\\IRCPeopleDirectory\\IRCPeopleDirectory"**-, hay un readme que te va a ayudar a hacer el setup y en la carpeta irc-directory-react-app
hay otro readme para hacer el setup de react tambien
avisame si te trabas con algo
nosotros solemos tener un virtualenv y dentro de esa carpeta, en una carpeta source bajamos el repo
si, porque generalmente configuramos varios proyectos en la misma maquina, y cada uno tiene sus versiones de las dependencias
entonces lo manejamos con virtualenv para poder hacerlo
![[log]]
