---
excalidraw-plugin: parsed
tags: [doc-type/excalidraw]
---
==⚠  Switch to EXCALIDRAW VIEW in the MORE OPTIONS menu of this document. ⚠==


# Text Elements
Este es el browser local, que diferente al que viene en el mail!!! ^jMF8ECyP


# Embedded files
d21744fbd88e388b31dca4ecb1640289453d47ea: [[Pasted Image 20230221151529_272.png]]
e1f4029a85f5496276618810c66786a589af5d6c: [[Pasted Image 20230221151529_284.png]]
249b5eb21b14d8f704d617b8f74af9380ef22fa3: [[Pasted Image 20230221151544_281.png]]
fdc15f19fef11d5fac17439a82c8e3ca3452d5fb: [[Pasted Image 20230221181853_762.png]]
b505fa3ab2afd6dea03be2825e5d39a3bd8c38e8: [[Pasted Image 20230221181953_779.png]]

%%
# Drawing
```json
{
	"type": "excalidraw",
	"version": 2,
	"source": "https://excalidraw.com",
	"elements": [
		{
			"type": "image",
			"version": 108,
			"versionNonce": 1567597936,
			"isDeleted": false,
			"id": "ivVzKdzt_fUjjh-jrJN04",
			"fillStyle": "hachure",
			"strokeWidth": 0.5,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -16.087301587301624,
			"y": -446.0355902777777,
			"strokeColor": "transparent",
			"backgroundColor": "transparent",
			"width": 398.6190476190476,
			"height": 484,
			"seed": 1887998832,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1677014322708,
			"link": null,
			"locked": false,
			"status": "pending",
			"fileId": "d21744fbd88e388b31dca4ecb1640289453d47ea",
			"scale": [
				1,
				1
			]
		},
		{
			"type": "image",
			"version": 63,
			"versionNonce": 786147728,
			"isDeleted": false,
			"id": "fwRE4NMvi_eBeRUBAobYK",
			"fillStyle": "hachure",
			"strokeWidth": 0.5,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -498.07956989247316,
			"y": -449.81336805555554,
			"strokeColor": "transparent",
			"backgroundColor": "transparent",
			"width": 386.15913978494626,
			"height": 484,
			"seed": 1302134672,
			"groupIds": [],
			"roundness": null,
			"boundElements": [
				{
					"id": "qYik2GBwmL0w_LxxeoGqM",
					"type": "arrow"
				}
			],
			"updated": 1677014322708,
			"link": null,
			"locked": false,
			"status": "pending",
			"fileId": "e1f4029a85f5496276618810c66786a589af5d6c",
			"scale": [
				1,
				1
			]
		},
		{
			"type": "image",
			"version": 53,
			"versionNonce": 2100918128,
			"isDeleted": false,
			"id": "ZLKQflm9nVXwGiruRzuxa",
			"fillStyle": "hachure",
			"strokeWidth": 0.5,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -304.36990414530084,
			"y": 151.87144886363632,
			"strokeColor": "transparent",
			"backgroundColor": "transparent",
			"width": 474.606125844016,
			"height": 440.9090909090909,
			"seed": 1566724464,
			"groupIds": [],
			"roundness": null,
			"boundElements": [
				{
					"id": "TQjAgoHZ2KS9U5kJijvn5",
					"type": "arrow"
				}
			],
			"updated": 1677014322708,
			"link": null,
			"locked": false,
			"status": "pending",
			"fileId": "249b5eb21b14d8f704d617b8f74af9380ef22fa3",
			"scale": [
				1,
				1
			]
		},
		{
			"type": "text",
			"version": 151,
			"versionNonce": 651163536,
			"isDeleted": false,
			"id": "jMF8ECyP",
			"fillStyle": "hachure",
			"strokeWidth": 0.5,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -336.66280081925237,
			"y": 69.97490530303048,
			"strokeColor": "#862e9c",
			"backgroundColor": "transparent",
			"width": 638,
			"height": 25,
			"seed": 1039359856,
			"groupIds": [],
			"roundness": null,
			"boundElements": [
				{
					"id": "TQjAgoHZ2KS9U5kJijvn5",
					"type": "arrow"
				},
				{
					"id": "qYik2GBwmL0w_LxxeoGqM",
					"type": "arrow"
				}
			],
			"updated": 1677014322708,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Este es el browser local, que diferente al que viene en el mail!!!",
			"rawText": "Este es el browser local, que diferente al que viene en el mail!!!",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Este es el browser local, que diferente al que viene en el mail!!!"
		},
		{
			"type": "arrow",
			"version": 144,
			"versionNonce": 1744374128,
			"isDeleted": false,
			"id": "TQjAgoHZ2KS9U5kJijvn5",
			"fillStyle": "hachure",
			"strokeWidth": 0.5,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -57.86529264882204,
			"y": 98.97490530303038,
			"strokeColor": "#862e9c",
			"backgroundColor": "transparent",
			"width": 4.5016184607943615,
			"height": 50.00000000000004,
			"seed": 1437231984,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1677014322709,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "jMF8ECyP",
				"focus": 0.11984276692252653,
				"gap": 3.9999999999998863
			},
			"endBinding": {
				"elementId": "ZLKQflm9nVXwGiruRzuxa",
				"focus": -0.05992156798360359,
				"gap": 2.89654356060592
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-4.5016184607943615,
					50.00000000000004
				]
			]
		},
		{
			"type": "arrow",
			"version": 163,
			"versionNonce": 1997178256,
			"isDeleted": false,
			"id": "qYik2GBwmL0w_LxxeoGqM",
			"fillStyle": "hachure",
			"strokeWidth": 0.5,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -56.664247803670364,
			"y": 60.086016414141454,
			"strokeColor": "#862e9c",
			"backgroundColor": "transparent",
			"width": 43.331886348915546,
			"height": 159.10083440409386,
			"seed": 130983824,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1677014322709,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "jMF8ECyP",
				"focus": -0.10171477885652648,
				"gap": 9.888888888889028
			},
			"endBinding": {
				"elementId": "fwRE4NMvi_eBeRUBAobYK",
				"focus": -0.6771397568012142,
				"gap": 11.924295954940959
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-43.331886348915546,
					-159.10083440409386
				]
			]
		},
		{
			"id": "Pd98-tyd7eOX9RrdFVaUb",
			"type": "image",
			"x": -266.3028739165234,
			"y": 413.2270064036778,
			"width": 503.86894231575707,
			"height": 841.4712718754091,
			"angle": 1.5820634556239428,
			"strokeColor": "transparent",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 0.5,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": null,
			"seed": 2056236944,
			"version": 155,
			"versionNonce": 1107048304,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1677014340336,
			"link": null,
			"locked": false,
			"status": "pending",
			"fileId": "fdc15f19fef11d5fac17439a82c8e3ca3452d5fb",
			"scale": [
				1,
				1
			]
		},
		{
			"id": "WeCNqikia5SOqE8u2WQm5",
			"type": "image",
			"x": -197.14613706889634,
			"y": 1132.5591838688842,
			"width": 211.48222604823127,
			"height": 328.14930346538165,
			"angle": 4.71238898038469,
			"strokeColor": "transparent",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 0.5,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": null,
			"seed": 1007229808,
			"version": 119,
			"versionNonce": 944934288,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1677014398332,
			"link": null,
			"locked": false,
			"status": "pending",
			"fileId": "b505fa3ab2afd6dea03be2825e5d39a3bd8c38e8",
			"scale": [
				1,
				1
			]
		},
		{
			"id": "76j4SQh4",
			"type": "text",
			"x": -49.53861781271655,
			"y": 942.9449829174093,
			"width": 59,
			"height": 25,
			"angle": 0,
			"strokeColor": "#862e9c",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 0.5,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": null,
			"seed": 77414768,
			"version": 2,
			"versionNonce": 955669360,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1677014322709,
			"link": null,
			"locked": false,
			"text": "x: 441",
			"rawText": "x: 441",
			"fontSize": 20,
			"fontFamily": 1,
			"textAlign": "left",
			"verticalAlign": "top",
			"baseline": 18,
			"containerId": null,
			"originalText": "x: 441"
		},
		{
			"id": "3fBdAN98",
			"type": "text",
			"x": -49.53861781271655,
			"y": 977.9449829174093,
			"width": 52,
			"height": 25,
			"angle": 0,
			"strokeColor": "#862e9c",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 0.5,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": null,
			"seed": 266718608,
			"version": 2,
			"versionNonce": 1019433872,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1677014322709,
			"link": null,
			"locked": false,
			"text": "y: 93",
			"rawText": "y: 93",
			"fontSize": 20,
			"fontFamily": 1,
			"textAlign": "left",
			"verticalAlign": "top",
			"baseline": 18,
			"containerId": null,
			"originalText": "y: 93"
		},
		{
			"id": "4IqiWtFM",
			"type": "text",
			"x": -49.53861781271655,
			"y": 1012.9449829174093,
			"width": 69,
			"height": 25,
			"angle": 0,
			"strokeColor": "#862e9c",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 0.5,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": null,
			"seed": 609457008,
			"version": 2,
			"versionNonce": 1652125040,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1677014322709,
			"link": null,
			"locked": false,
			"text": "w: 568",
			"rawText": "w: 568",
			"fontSize": 20,
			"fontFamily": 1,
			"textAlign": "left",
			"verticalAlign": "top",
			"baseline": 18,
			"containerId": null,
			"originalText": "w: 568"
		},
		{
			"id": "97M6AuPh",
			"type": "text",
			"x": -49.53861781271655,
			"y": 1047.9449829174093,
			"width": 65,
			"height": 25,
			"angle": 0,
			"strokeColor": "#862e9c",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 0.5,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": null,
			"seed": 720739216,
			"version": 2,
			"versionNonce": 775053712,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1677014322709,
			"link": null,
			"locked": false,
			"text": "h: 905",
			"rawText": "h: 905",
			"fontSize": 20,
			"fontFamily": 1,
			"textAlign": "left",
			"verticalAlign": "top",
			"baseline": 18,
			"containerId": null,
			"originalText": "h: 905"
		}
	],
	"appState": {
		"theme": "dark",
		"viewBackgroundColor": "#fff",
		"currentItemStrokeColor": "#862e9c",
		"currentItemBackgroundColor": "transparent",
		"currentItemFillStyle": "hachure",
		"currentItemStrokeWidth": 0.5,
		"currentItemStrokeStyle": "solid",
		"currentItemRoughness": 1,
		"currentItemOpacity": 100,
		"currentItemFontFamily": 1,
		"currentItemFontSize": 20,
		"currentItemTextAlign": "left",
		"currentItemStartArrowhead": null,
		"currentItemEndArrowhead": "arrow",
		"scrollX": 372.8502938284631,
		"scrollY": -927.8265879266855,
		"zoom": {
			"value": 1.6976560189312002
		},
		"currentItemRoundness": "round",
		"gridSize": null,
		"colorPalette": {},
		"currentStrokeOptions": null,
		"previousGridSize": null
	},
	"files": {}
}
```
%%