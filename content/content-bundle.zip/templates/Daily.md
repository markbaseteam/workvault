Start: <% tp.date.now("HH:mm", 1) %>
# <% tp.date.now("dddd, MMMM DD, YYYY") %>
<%*
await tp.file.move("Daily/" + tp.date.now("YYYY-MM-DD") );
const first = '(@'+tp.date.now("YYYY-MM-DD") + ' 12:00:00)'
const second = '(@'+ tp.date.now("YYYY-MM-DD") + ' 14:00:00)'
const third = '(@'+ tp.date.now("YYYY-MM-DD") + ' 14:30:00)'
-%>---
- [ ] Look at teams, say hi
- [ ] Look at outlook
- [ ] Look at calendar
- [ ] Look at the board
<% (new Date()).getDay() === 2 ? `- [ ] ${first} Requirements Refinement Meeting: Martha Fowler [Join conversation](https://teams.microsoft.com/l/meetup-join/19%3ameeting_ZWNkNGFhNGEtZGM4ZS00MGQ3LWJjZTctMWI3Y2JiMjU4MDU1%40thread.v2/0?context=%7b%22Tid%22%3a%2205f1318c-6783-4326-b729-bf537a761db8%22%2c%22Oid%22%3a%2269d15c2f-af68-47ac-9e7f-67c10f7b889d%22%7d)`:'' %>- [ ] <% `${second}  [Stand Up](https://teams.microsoft.com/l/meetup-join/19%3ameeting_NzFkNDE3ZDEtYjAwNi00OGUyLWEwNTEtM2ZiODdhZDAyNGEz%40thread.v2/0?context=%7b%22Tid%22%3a%2205f1318c-6783-4326-b729-bf537a761db8%22%2c%22Oid%22%3a%22f76fade0-1c05-4f94-b120-b1ac482a1dd7%22%7d)`%>
<% (new Date()).getDay() === 4 ? `${third} [Sprint Planning Session](https://teams.microsoft.com/l/meetup-join/19%3ameeting_YzlkNGE3NzItNGU2YS00ZjkzLTgwNDUtMDQzOWE3ZTE0ODc5%40thread.v2/0?context=%7b%22Tid%22%3a%2205f1318c-6783-4326-b729-bf537a761db8%22%2c%22Oid%22%3a%2269d15c2f-af68-47ac-9e7f-67c10f7b889d%22%7d)`:'' %>
---
# Todays work
## Tickets
- <% tp.file.cursor() %>



---
Metadata

Tags:: <% `[[Tags/Daily${'-'}tag]]` %> <% `#` %>active
creation-date:: <% tp.date.now("YYYY-MM-DD ddd HH:mm:ss") %>
