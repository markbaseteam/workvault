<%*
  let title = tp.file.title
  if (title.startsWith("Untitled")) {
    title = await tp.system.prompt("Title");
    await tp.file.move("Docs/" + title);
  }
%><% tp.file.cursor() %>




---
Metadata

Tags:: <% `[[Tags/Docs${'-'}tag]]` %> <% `#` %>doc
creation-date:: <% tp.date.now("YYYY-MM-DD ddd HH:mm:ss") %>


