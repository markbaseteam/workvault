<%*
  let name = tp.file.title
  if (name.startsWith("Untitled")) {
    name = await tp.system.prompt("Name");
    await tp.file.move("People/" + name);
  }
%><% tp.file.cursor() %>




---
Metadata

Tags:: <% `[[Tags/People${'-'}tag]]` %> <% `#` %>people/<% name.replace(/ /g, '') %>
creation-date:: <% tp.date.now("YYYY-MM-DD ddd HH:mm:ss") %>


