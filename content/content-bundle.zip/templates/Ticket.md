<%*
// const ID = await tp.system.prompt("Ticket ID:");
//const description = (await tp.system.prompt("Description:")).replace('/', ' ').replace('?', ' ').replace(':', ' ').replace('&', ' ').replace(',', ' ').replace('.', ' ');
const ticket = await tp.system.prompt("Ticket:")
const {id, description, url} = await tp.user.jsForTicketTemplate(tp, ticket)
await tp.file.move("Tickets/" + id);
-%>
# <% id %> ^id
## <% description %> ^title
	<% url %> ^url

## Description ^description
<% tp.file.cursor() %>

---

## <% tp.date.now('YYYY-MM-DD') %> ^work
---


## Comments
```dialogue
left: Shimul Ahmed
right: Juan Pablo Sala

< 
> 

```


---
Metadata

Tags:: <% `[[Ticket${'-'}tag]]` %> <% `#` %>active <% `#` %>ticket
creation-date:: <% tp.date.now("YYYY-MM-DD ddd HH:mm:ss") %>
ID:: "<% id %>"
description:: "<% description  %>"
url:: "<% url  %>"

