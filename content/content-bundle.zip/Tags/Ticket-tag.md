# Active Tickets

```dataviewjs

dv.view('/JS/Ticket/activeTickets')

```

