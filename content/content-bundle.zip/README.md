# work.vault

> [!INFO]
> ## Obsidian Vault to mange work docs/notes/planning/etc

