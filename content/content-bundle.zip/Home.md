```dataviewjs

dv.view('/JS/Ticket/activeNotes')

```

