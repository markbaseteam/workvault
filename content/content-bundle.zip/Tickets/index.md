# Active tickets
```dataviewjs
dv.view('Ticket/activeTickets')
```


