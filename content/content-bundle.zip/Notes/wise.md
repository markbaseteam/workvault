# Wise
https://wise.com/home/
![](https://i.imgur.com/ffEhF99.png)


![](comprobante_3073977%201.pdf)
#### Wise desde Argentina: 3 métodos para fondear y activar tu cuenta
https://wise.com/ar/blog/como-fondear-transferwise-argentina
https://www.reddit.com/r/merval/comments/m2qeit/c%C3%B3mo_fondear_transferwise_con_global66_y_cobrar/

#### Doc que me pasó Federigo
https://pirlutravel.com/wise-argentina-2021/

#### Global66
https://transferencias.global66.com/home

### Doc de Thinkersys
https://docs.google.com/document/d/1Ap7kig9-ezkC1AB5-bMp-XXvcFBgosu3hctmmTs3BSs/edit#

---
Metadata
Tags:: [[Notes-tag]] #doc-type/note 
creation-date:: 2023-02-10 Mon 20:58:25