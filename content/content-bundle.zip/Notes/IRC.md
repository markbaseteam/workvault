[International Rescue Committee | International Rescue Committee (IRC)](https://www.rescue.org/)
[[People Directory]]



---
Metadata

Tags:: [[Tags/Notes-tag]] note
creation-date:: 2023-02-22 Wed 09:40:38


