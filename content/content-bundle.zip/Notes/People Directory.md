# [![](https://confluence.rescue.org/download/attachments/131074/global.logo?version=4&modificationDate=1313083940000)](https://confluence.rescue.org/display/APDV)[People Directory](https://confluence.rescue.org/display/APDV/People+Directory)

-   [Business purpose of the application/integration service](https://confluence.rescue.org/display/APDV/People+Directory#PeopleDirectory-Businesspurposeoftheapplication/integrationservice)
-   [User focused diagram](https://confluence.rescue.org/display/APDV/People+Directory#PeopleDirectory-Userfocuseddiagram)
-   [**Integrations:**](https://confluence.rescue.org/display/APDV/People+Directory#PeopleDirectory-Integrations:)

-   [**Cornerstone**](https://confluence.rescue.org/display/APDV/People+Directory#PeopleDirectory-Cornerstone)
-   [**Active Directory**](https://confluence.rescue.org/display/APDV/People+Directory#PeopleDirectory-ActiveDirectory)
-   [AD Integration Troubleshoot](https://confluence.rescue.org/display/APDV/People+Directory#PeopleDirectory-ADIntegrationTroubleshoot)
-   [AD account fix tools](https://confluence.rescue.org/display/APDV/People+Directory#PeopleDirectory-ADaccountfixtools)
-   [Terminations and Deactivations](https://confluence.rescue.org/display/APDV/People+Directory#PeopleDirectory-)
-   [**Environments**](https://confluence.rescue.org/display/APDV/People+Directory#PeopleDirectory-Environments)
-   [**State diagram: workflow of an account request:**](https://confluence.rescue.org/display/APDV/People+Directory#PeopleDirectory-Statediagram:workflowofanaccountrequest:)
  
### Business purpose of the application/integration service

People Directory is an essentially a master database where all Employees working at the IRC there IT Data and some HR data is kept up to date. This data is also synced with systems based on the Employee Types. The systems that are integrated currently are Active Directory, Cornerstone and Integra (Dynamics D365).

People Directory also has an interface, which allows new Employee Request to be created and go through the workflow of the approval process and records created in the relevant systems.

### User focused diagram

**General Architecture** 

![](https://confluence.rescue.org/download/attachments/41847877/ED%20Arch.jpeg?version=1&modificationDate=1551953777000)

### **Integrations:**

#### **Cornerstone**

**Create (FunctionCreateEmployee)**: This is an Azure function that allows us to create a user in Cornerstone on approval of an Employee Request in People Directory. The Cornerstone endpoint that is called in this case is: https://rescue.csod.com/services/api/x/users/v1/employees. There are also custom fields that are sent which include Location, Supervisory and Cost Centers.  
In People Directory the method **create_cs_user** calls this FunctionCreateEmployee**.** create_cs_user(person) -> FunctionCreateEmployee(request) -> CS(personMappedToCSformat) -> returns an employee id and sents it to PD.

**Update (FunctionUpdateEmployee):** Updates a record in Cornerstone based on changes in Person entity in People Directory. Updates to Cornerstone is restricted to only Email and Username fields since Cornerstone is the source of these people's records. AD controls the username and email that flows back into Cornerstone. The API Endpoint used in this case is: https://rescue.csod.com/services/api/x/users/v1/employees/{Cornserstone_Employee_ID}. The Cornerstone Employee ID is stored in People Directory.  
update_cs_user(person) -> FunctionCreateEmployee(request)

The **FunctionCreateEmployee** and **FunctionUpdateEmployee** don't use queue messages.  
They are not being called from another azure functions.

**Check for Updates:** Periodically check for updates (every 1 hour, prod and qa have the same config) in cornerstone for Employee changes, deactivations and terminations (of the last 5 hours). All changes are put on an Azure queue that is periodically accessed by another Azure function to send updates in batches to People Directory (to this endpoint updateUsersFromCS/ ). In order to get updates we call the API endpoint: https://rescue.csod.com/services/api/x/users/v1/employees. We filter the url with the **lastmodifieddate** field. Since each of these users we also need to get the Custom fields which include Location, Supervisory and Cost Centers we use the Reporting API to extract that data. The reporting API endpoint used to get that data https://rescue.csod.com/services/api/x/odata/api/views/vw_rpt_user_cf. 

 Another part of this function is to also extract Terminated and Deactivated Users for this we use the same Reporting endpoint https://rescue.csod.com/services/api/x/odata/api/views/vw_rpt_user_cf , the filter field is **_last_touched_dt_utc.** The **user_status_id** returned through this API tells us if the user needs to be deactivated right away in All systems or they need to be terminated. Terminations are different since they can happen on a future date and the field returned from the API **user_termination_dt** gets that user added in an Azure queue to be terminated in all systems on that given date.

**OU Data:** As mentioned above there are custom fields which include Location, Supervisory and Cost Centers. These need be in People Directory so the Hiring managers can select the appropriate values within People Directory at the time of creation which are sent back to Cornerstone via the Rest API calls. These are also needed for the updates received from Cornerstone. To get this data copied we have created an Azure functions which returns us the data required in a json format which then used by the helper functions to update Locations, Supervisory and Cost Centers controls lists within People Directory Application. The Reporting API that is used in this scenario is https://rescue.csod.com/services/api/x/odata/api/views/vw_rpt_ou. We filter by **type_id** (e.g Location) to get the appropriate data set. 

**Note:** Currently the employees that are synced between CS and ED are **Short Term, Regular, Limited, Occasional **and AmeriCorps****. Also any record in ED that is connected to Cornerstone will have a Cornerstone Object ID (cs_object_id)

Help for Cornerstone API can be found here: [https://lax-pil-ex.csod.com/apiconnectorweb/apiexplorer#/apidoc/7f1beda8-ec8a-41ad-a615-417d27d8e568](https://lax-pil-ex.csod.com/apiconnectorweb/apiexplorer#/apidoc/7f1beda8-ec8a-41ad-a615-417d27d8e568)

All the fields that are used with Cornerstone API for updates in People Directory or creation of an Employee in Cornerstone can be found here: [https://rescue.app.box.com/file/322106645263](https://rescue.app.box.com/file/322106645263)

**FunctionTriggerUpdateEDFromCS**: related to ticket ED-411

Updates the OUs every one hour

This Azure function calls the following endpoints of PD:

createOrUpdateCSLocations  
createOrUpdateCSDepartments  
createOrUpdateCSCostCenters  
createOrUpdateCSBusinessUnits

All of the above calls the Azure function CSOUDataFunction, this one gets the data from cornerstone.

So the data flow is the following:

FunctionTriggerUpdateEDFromCS  -> createOrUpdateCSLocations -> CSOUDataFunction -> createOrUpdateCSLocations  
                                                              createOrUpdateCSDepartments -> CSOUDataFunction  -> createOrUpdateCSDepartments  
                                                              createOrUpdateCSCostCenters -> CSOUDataFunction  -> createOrUpdateCSCostCenters                                                              createOrUpdateCSBusinessUnits -> CSOUDataFunction -> createOrUpdateCSBusinessUnits

  
 

#### **Active Directory**

**Overview:** The Active Directory integration is automated. Before release on 10/10/2022, PD was sending helpdesk and servicenow an email with the details of the user to be created and then it was a manual work to get the user added to AD. Now, PD will connect to AD and create the employee automatically. The user receives a welcome email, with the credentials and instructions. The user needs to be able to login rescue.org, selfservice.rescue.org, box, outlook email and MS Teams.

For enabling those accesses, the user is set with some groups in AD. Each OU has a group called  'Members - <name of the OU>' inside that has to be assigned to the newly created user. There are some other groups that are assigned to the user: ALLUSERS; Box Managed Users; Interact Managed Users; RescueNetFullAccess. The user will also get a 365 license. That is set by assigning the user to the AD group 'License-M365E3'

Users that are located in United Kingdom are expected to have the primary email with the domain @rescue-uk.org and also have the regular domain @rescue.org , being the uk one primary email address.

There's now new features around the AD accounts:

-   Add an IT Account to an existing user. This works for users that didn't have an account in AD. It works the same way as the creation of an account. It calls the same service that when an AD account is created from the account request.
-   Unlock IT account: sends an email to helpdesk and servicenow with the users information. Helpdesk manually unloks the user account when they get the request
-   Remove IT Account: this works for users that have an active AD user. This deactivates the account in AD. Removes all the groups assigned to a user and moves the user to the Disabled OU

With the Add IT account, or Rehire functionality, the creation of the AD account works this way. First, the system will check if the user already existed in AD. If not, it will create it right away. If the user already existed, it will move to the corresponding OU (it was on the disabled OU probably) , assigne the corresponding groups, inlcuding the Memeber - xxx group corresponding to the new OU. License group does not need to be set again if the account was already there (even if it was disabled)

Change Worker Type functionality allows to set the new type of the person, no restriction of types changing for now. This also allows to change the ou of an existing person, so the AD service will do that change, Also, it needs to remove the previous 'Members - xxx' group for the previous OU and set the right related to the new OU.

**Azure:**

**Create**: This is an Azure function that allows us to create a user in AD on approval of an Employee Request in Cornerstone.

**Update:** Updates a record in AD based on changes in Entity in People Directory.

**Check for Updates:** There is a Azure function that periodically check for any changes in AD and sends those changes to People Directory where the corresponding record is updated.

**FunctionScheduleSetUserLicense**: This function is called from PD when the user is created. This receives the Employee ID and puts it in a queue with one hour delay to call function SetUserLicense. We need this delay to allow for the user to be created and visible by the Azure AD library, before setting the license

**SetUserLicense**: This function calls to the active directory service endpoint to set the users license. The service assigns the user to an AD group, which grants the user with a 365 License

**Note:** Currently the employees being synced between AD and ED are **Consultants, Volunteers, Interns and Temporary**. Also all the records that are connect to AD will have an AD Object ID (ad_object_id) in ED.

  

#### AD Integration Troubleshoot

When the integration fails there's an email sent to notify this situation:

If the account could not be created at all in AD, the email will have the subject 'error when creating user in AD with automation'. We need to check in the email body to find for the problem.

The most common one is "_Fail to create the user: Active Directory operation failed on nydc00.theirc.org. The object 'CN=Salem Abdon,OU=Yemen,OU=East Africa,OU=Regions,OU=International Programs,OU=All Users,DC=theirc,DC=org' already exists._" where _Salem Abdon_ is the name of the user being created. It's common to get this as a false positive, and the account is configured correctly .To check this, you need to open the Azure portal, in the search select Active Directory, go to Users and search for the user. Check if the user exists there and see if the account is setup correctly (see image below). If after at least 2 hours the account is not there, then you will need to check the issue and fix the problem. Sometimes the account creation fails because the user name or last name contains an accented character , like é, á or some other special character. If that happened, you need to ask Chelsea Easter to update and remove the character. Once the account is fixed, you need to fire the account setup again.For that you need to run the AzureFunction FunctionCreateADAccountInED from the CornerstoneConnectorAppAzureProduction. You can run it directly from Azure providing the Account Request #. That will connect with the PD app and get the account created and setup, also sending the welcome email

Another possible cause of error in account creation can be related to the OU, that does not exist in AD. The email will say _Fail to create the user: Organizational unit "[theirc.org/All](http://theirc.org/All) Users/Global Partnerships and Philanthropy/Development/Major Gifts" was not found. Please make sure you have typed it correctly_ For this , you need to coordinate with Tabasum, to get the OU created or fixed in AD, and after that, run the AF to create the account, as above.

  

Another failure email is 'error when completing setup user in AD with automation' . That means the user account was successfully created in AD and the welcome email was sent. The issue happened at a later time, when PD called the AD service to send the full user information. Usually the problem here is because of a special or accented character. Once that is fixed we need to call the FunctionCompleteAccountSetup and also the SetUserLicense functions. Those functions are under the ActiveDirectoryConnectorAppAzureProduction. For running these functions you need to provide the IRC MasterId.

Remember that if the complete setup function failed, the Set license will also fail. So when manually running the Complete  function, you need to wait half an hour and then run the SetUserLicense function.

  

  

An account that has been correctly setup in AD will look like this, having 6 groups and 1 license. Account is created right away, with basic data, you can verify the ad_object_id was set in PD. After 30 minutes, the complete account setup is run, setting all the remaining information on the user and assigning 5 groups. 90 minutes after account creation, the SetLicense function runs , assigning one more group to the user (that group adds a license to the user)

![](https://confluence.rescue.org/download/attachments/41847877/image2022-11-2%2015%3A6%3A16.png?version=1&modificationDate=1667412377000)

  

  

#### AD account fix tools

In PD, in the Person administration, there are 3 new options that can be used to try to fix an account that had issues while created in AD. To use these, you need to select the user you want to fix, by clicking on the checkbox in the first column. Then select the Action and click Go. You can select one or more users.

![](https://confluence.rescue.org/download/attachments/41847877/image2022-11-23%2015%3A36%3A24.png?version=1&modificationDate=1669228584000)

-   **Resend welcome email:** Sends the Welcome email to the user. It sends to the user's personal email.
-   **Complete ad user account setup:** It set's the user information and groups in AD. This is useful for when the user has been created in AD (first step in the automation process) but the user information, like Employee ID, address, groups or so, were not set correctly in AD
-   **Set ad user license:** This option sets the D365 license in AD for the selected users

####   

#### Terminations and Deactivations

**Terminations started by Cornerstone:**

![](https://confluence.rescue.org/download/attachments/41847877/Termination%20CS.jpeg?version=1&modificationDate=1551953777000)

There are different ways an account can get terminated or deactivated in ED, CS and AD. Short Term, Regular, Limited and Occasional employees can get either terminated or deactivated through Cornerstone, which in turn will update ED, and ED will update AD and Integra.

For Volunteers, Interns and Temporary employees AD will be source of termination based on the “endOf” field in AD. Whenever that date is past due the account in AD and ED will be deactivated.

### **Environments**

The application is deployed as an App service in Azure and there are different slots for QA and Production.

**QA**: [https://ircpeopledirectory-app-qa.azurewebsites.net/](https://ircpeopledirectory-app-qa.azurewebsites.net/)

**Production**: [https://ircdirectory.rescue.org/](https://ircdirectory.rescue.org/)

**DEV Note:** 

Incase we get a request to create persons in PD. Attached is the script. [SQL to insert Persons (PD).sql](https://confluence.rescue.org/download/attachments/41847877/SQL%20to%20insert%20Persons%20%28PD%29.sql?version=1&modificationDate=1623349716000)

The App Service in the Azure portal is called **IRCPeopleDirectory** and has it's related **QA** and **Staging** deployment slots.

![](https://confluence.rescue.org/download/attachments/41847877/image2021-9-24%2016%3A24%3A31.png?version=1&modificationDate=1632511472000)

### **State diagram: workflow of an account request:**

The following diagram shows the workflow of an account request.

There are 2 groups of users in the application, the Hiring Manager group and the HR Ops group.

An account request goes through different status in his life cycle. Those status are represented by the ellipsis figures. 

The arrows represent the actions that a specific group can do.

![](https://confluence.rescue.org/download/attachments/41847877/state_diagram.png?version=1&modificationDate=1626469038000)

---
Metadata

Tags:: [[Tags/Notes-tag]] #note
creation-date:: 2023-02-22 Wed 09:41:13


