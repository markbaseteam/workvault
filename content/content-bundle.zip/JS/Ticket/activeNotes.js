const notes = dv.pages('#active and -"templates"').sort((p,n)=>{
  console.log('detalle' , n);
  return p.file.ctime
  return p.file.mtime< n.file.mtime
})
// console.clear()
// console.log('detalle2', tickets.values);
// tickets.values.forEach(t => {
  // console.log('ticket', t)
  // dv.el('div', JSON.stringify(t))
// })
dv.table(['Type', 'Description', 'm-date'], notes.map(t => {
  const date = t.file.mtime.toFormat('yyyy/MM/dd')
  if(t.file.folder === 'Tickets') 
    return ['Ticket', dv.fileLink(t.file.path,false,`${t.id}: ${t.description}`), date]
  else if (t.file.folder === 'Notes') 
    return ['Note', t.file.link, date]
  else if (t.file.folder === 'Daily') 
    return ['Daily', t.file.link, date]
    else (t.file.folder === 'Daily') 
    return ['', t.file.link, date]
}))

