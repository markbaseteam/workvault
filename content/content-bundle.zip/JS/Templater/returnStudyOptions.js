function returnStudyOptions (tp, timeAvailable) {
  console.log('detalle', );
  let result = "";

  result += `### Hola:\n\n`;
  const dv = app.plugins.plugins.dataview.api
  const pages = dv.pages('[[Tags/Ticket]] and -"templates"')

  pages.forEach((option) => {
      result += `- ${option.file.link}\n\n`
  })

  return result
}

module.exports = returnStudyOptions;
